/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Loader2, Sparkles, Wand2, Volume2, Share2, RefreshCw, X } from 'lucide-react';
import { generateStoryScript, generateTTS, generateSceneImage, type StoryScript } from './services/gemini';
import { cn } from './lib/utils';

export default function App() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'create' | 'preview'>('create');
  const [script, setScript] = useState<StoryScript | null>(null);
  const [generatedContent, setGeneratedContent] = useState<{
    images: string[];
    audio: string | null;
  }>({ images: [], audio: null });
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('');

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setError(null);
    setStatus('Decoding the secrets...');
    
    const messages = [
      'Decoding the secrets...',
      'Crafting an emotional narrative...',
      'Visualizing the hidden truth...',
      'Recording the dramatic voice...',
      'Synchronizing the heartbeats...',
      'Polishing for viral impact...'
    ];
    
    let msgIndex = 0;
    const interval = setInterval(() => {
      msgIndex = (msgIndex + 1) % messages.length;
      setStatus(messages[msgIndex]);
    }, 3000);
    
    try {
      // 1. Generate Script
      const newScript = await generateStoryScript(prompt);
      setScript(newScript);
      
      // 2. Generate Assets
      const imagePromises = newScript.scenes.map(scene => generateSceneImage(scene.imagePrompt));
      const images = await Promise.all(imagePromises);
      
      const fullText = newScript.scenes.map(s => s.text).join('. ');
      const audioBase64 = await generateTTS(fullText);
      const audioUrl = `data:audio/wav;base64,${audioBase64}`;
      
      setGeneratedContent({ images, audio: audioUrl });
      setActiveTab('preview');
      clearInterval(interval);
    } catch (err: any) {
      console.error(err);
      setError('Generation failed. The story was too powerful for the machines.');
      clearInterval(interval);
    } finally {
      setIsGenerating(false);
      setStatus('');
    }
  };

  return (
    <div className="relative min-h-screen font-sans selection:bg-accent/30 selection:text-white">
      <div className="atmosphere" />
      
      {/* Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 p-10 flex justify-between items-center bg-gradient-to-b from-[#080808] to-transparent">
        <div className="flex items-center gap-2 group cursor-pointer">
          <h1 className="font-serif italic text-4xl tracking-tighter text-white">Whisper.</h1>
        </div>
        
        <div className="flex gap-8">
          <button 
            onClick={() => setActiveTab('create')}
            className={cn(
              "text-[11px] uppercase tracking-[0.2em] font-bold transition-all hover:text-accent",
              activeTab === 'create' ? "text-accent border-b-2 border-accent pb-1" : "text-white/40"
            )}
          >
            Editor
          </button>
          <button 
            disabled={!script}
            onClick={() => setActiveTab('preview')}
            className={cn(
              "text-[11px] uppercase tracking-[0.2em] font-bold transition-all hover:text-accent disabled:opacity-30 disabled:cursor-not-allowed",
              activeTab === 'preview' ? "text-accent border-b-2 border-accent pb-1" : "text-white/40"
            )}
          >
            Preview
          </button>
        </div>
      </nav>

      <main className="pt-40 pb-20 px-10 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-[380px_1fr] gap-16 items-start">
        {/* Left Side: Input area */}
        <div className="space-y-10">
          <header className="space-y-4">
            <div className="text-[11px] uppercase tracking-[0.2em] text-white/40 font-bold">The Raw Secret</div>
            <motion.h2 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-4xl font-serif italic tracking-tight text-white/90"
            >
              Transform your story into <br />
              <span className="text-accent not-italic font-sans font-black uppercase tracking-tighter">Pure Viral Gold.</span>
            </motion.h2>
          </header>

          <div className="space-y-6">
            <div className="relative group">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Type the confession or story here..."
                className="w-full h-72 glass rounded-2xl p-8 text-lg font-serif italic text-white/70 focus:outline-none focus:border-accent/30 transition-all border border-white/5 resize-none placeholder:text-white/10"
              />
              
              <div className="absolute top-4 right-4">
                {isGenerating && (
                  <Loader2 className="w-5 h-5 text-accent animate-spin" />
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-[10px] uppercase tracking-widest text-white/30 font-bold">Vibe</div>
                <div className="glass px-4 py-3 rounded-xl text-xs font-bold text-white/60">Emotional</div>
              </div>
              <div className="space-y-2">
                <div className="text-[10px] uppercase tracking-widest text-white/30 font-bold">Pace</div>
                <div className="glass px-4 py-3 rounded-xl text-xs font-bold text-white/60">Fast / Viral</div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full py-5 rounded-2xl bg-accent text-white font-black uppercase tracking-[0.1em] text-sm hover:translate-y-[-2px] hover:shadow-[0_10px_30px_rgba(225,29,72,0.4)] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl relative overflow-hidden"
            >
              <span className="relative z-10">{isGenerating ? status : 'Craft Viral Story'}</span>
            </button>
          </div>

          <div className="space-y-4">
            <div className="text-[10px] uppercase tracking-widest text-white/30 font-bold">Themes</div>
            <div className="flex flex-wrap gap-2">
              {['The Hidden Chef', 'Ex-Lover Wedding', 'Morning Confession', 'The Final Ride'].map(theme => (
                <button
                  key={theme}
                  onClick={() => setPrompt(`Theme: ${theme}. Write a highly emotional viral story about this.`)}
                  className="px-4 py-2 rounded-lg border border-white/5 bg-white/[0.02] text-[10px] font-bold text-white/40 hover:bg-white/5 hover:text-accent transition-all uppercase tracking-widest"
                >
                  {theme}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Preview area */}
        <div className="relative h-full flex items-center justify-center">
          <AnimatePresence mode="wait">
            {activeTab === 'preview' && script ? (
              <VideoPreview 
                script={script} 
                images={generatedContent.images} 
                audio={generatedContent.audio} 
              />
            ) : (
              <div className="aspect-[9/16] w-full max-w-[340px] glass rounded-[3rem] p-12 flex flex-col items-center justify-center text-center gap-6 border-white/5 shadow-2xl">
                <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center animate-pulse border border-accent/20">
                  <Sparkles className="w-8 h-8 text-accent" />
                </div>
                <div className="space-y-2">
                  <div className="text-[10px] uppercase tracking-widest text-accent font-black">Waiting Room</div>
                  <h3 className="font-serif italic text-2xl text-white/80">Silent Cinema</h3>
                  <p className="text-white/20 text-xs leading-relaxed">Your narrative transformation will appear here once the secret is shared.</p>
                </div>
              </div>
            )}
          </AnimatePresence>

          {/* Viral Potential Mockup */}
          {script && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="absolute top-20 right-[-40px] hidden xl:block glass p-6 rounded-2xl border-white/10 w-64 space-y-3"
            >
              <div className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Viral Potential</div>
              <div className="text-4xl font-black text-accent">98.4%</div>
              <div className="text-[10px] text-white/30 italic">High Retention Hook Detected</div>
            </motion.div>
          )}
        </div>
      </main>


      <footer className="fixed bottom-0 left-0 right-0 p-6 text-center text-white/20 pointer-events-none">
        <p className="text-[10px] uppercase tracking-[0.4em] font-mono">Confessional AI — All stories are anonymous</p>
      </footer>
    </div>
  );
}

function VideoPreview({ script, images, audio }: { script: StoryScript; images: string[]; audio: string | null }) {
  const [currentScene, setCurrentScene] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentScene((prev) => (prev + 1) % script.scenes.length);
      }, script.scenes[currentScene]?.duration * 1000 || 3000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, currentScene, script.scenes]);

  const handlePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="aspect-[9/16] w-[340px] h-[600px] border-[12px] border-[#1a1a1a] rounded-[48px] overflow-hidden shadow-2xl relative group bg-black"
    >
      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-4 bg-[#1a1a1a] rounded-full z-50 overflow-hidden">
        <div className="status-badge absolute inset-0 flex items-center justify-center text-[8px] font-bold text-accent uppercase leading-none">Live</div>
      </div>

      {/* Visual Canvas */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentScene}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0"
        >
          <img 
            src={images[currentScene]} 
            className="w-full h-full object-cover" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/20 opacity-80" />
        </motion.div>
      </AnimatePresence>

      {/* High-Impact Subtitles */}
      <div className="absolute inset-x-6 bottom-32 z-10">
        <AnimatePresence mode="wait">
          <motion.p
            key={currentScene}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="subtitles"
          >
            {script.scenes[currentScene].text}
          </motion.p>
        </AnimatePresence>
      </div>

      {/* Audio Visualizer Mock */}
      <div className="absolute bottom-20 left-6 z-20 flex items-end gap-[3px] h-8">
        {[12, 24, 18, 30, 20, 14, 22, 10].map((h, i) => (
          <motion.div
            key={i}
            animate={{ height: isPlaying ? [h, h * 1.5, h * 0.5, h] : h }}
            transition={{ repeat: Infinity, duration: 0.5, delay: i * 0.1 }}
            className="w-[3px] bg-white rounded-full opacity-60"
          />
        ))}
      </div>

      {/* Progress Bars */}
      <div className="absolute top-10 left-6 right-6 flex gap-1 z-20 opacity-40">
        {script.scenes.map((_, idx) => (
          <div key={idx} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-white"
              initial={{ width: 0 }}
              animate={{ 
                width: idx === currentScene ? '100%' : (idx < currentScene ? '100%' : '0%') 
              }}
              transition={{ 
                duration: idx === currentScene ? script.scenes[idx].duration : 0.1,
                ease: 'linear'
              }}
            />
          </div>
        ))}
      </div>

      {/* Audio Element */}
      {audio && <audio ref={audioRef} src={audio} onEnded={() => setIsPlaying(false)} />}

      {/* Controls Overlay */}
      <div className="absolute inset-0 flex items-center justify-center z-30 opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          onClick={handlePlay}
          className="p-6 rounded-full glass hover:bg-white/10 transition-all scale-125 shadow-2xl"
        >
          {isPlaying ? (
            <X className="w-8 h-8 text-white" />
          ) : (
            <Wand2 className="w-8 h-8 text-accent fill-current" />
          )}
        </button>
      </div>

      {/* Viral UI Overlay */}
      <div className="absolute right-4 bottom-20 flex flex-col gap-6 items-center z-20">
        {[
          { icon: Share2, label: 'Share' },
          { icon: RefreshCw, label: 'Export' }
        ].map((item, i) => (
          <div key={i} className="flex flex-col items-center gap-1 opacity-60 hover:opacity-100 transition-opacity">
            <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center border border-white/5 cursor-pointer">
              <item.icon className="w-4 h-4 text-white" />
            </div>
            <span className="text-[8px] uppercase font-bold tracking-[0.2em] text-white/60">{item.label}</span>
          </div>
        ))}
      </div>

      <div className="absolute bottom-10 left-8 z-20">
        <h4 className="font-serif italic text-white/40 text-[10px] tracking-widest uppercase">Whisper Cinema 01</h4>
      </div>
    </motion.div>
  );
}
