import { GoogleGenAI, Modality, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export interface StoryScript {
  originalStory: string;
  viralTitle: string;
  scenes: {
    text: string;
    imagePrompt: string;
    duration: number; // in seconds
  }[];
}

export async function generateStoryScript(userPrompt: string): Promise<StoryScript> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Rewrite this story into a viral, emotional TikTok/Reels/Shorts script. 
    Focus on hooks, secrets, and emotional tension. 
    
    Story: ${userPrompt}
    
    Break it down into 4-6 scenes. For each scene, provide the narrative text and a descriptive image prompt for a cinematic visual.
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          originalStory: { type: Type.STRING },
          viralTitle: { type: Type.STRING },
          scenes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING, description: "The narration text for this scene." },
                imagePrompt: { type: Type.STRING, description: "Detailed cinematic visual description." },
                duration: { type: Type.NUMBER, description: "Estimated duration in seconds (2-5 seconds per scene)." }
              },
              required: ["text", "imagePrompt", "duration"]
            }
          }
        },
        required: ["originalStory", "viralTitle", "scenes"]
      }
    }
  });

  return JSON.parse(response.text);
}

export async function generateTTS(text: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-tts-preview",
    contents: [{ parts: [{ text: `Say with deep, emotional, dramatic viral storytelling tone: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Charon' }, // Charon for a deep male voice, or Zephyr/Fenrir
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Failed to generate audio");
  return base64Audio;
}

export async function generateSceneImage(prompt: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: `A cinematic, moody, vertical 9:16 high-quality image: ${prompt}` }],
    },
    config: {
      imageConfig: {
        aspectRatio: "9:16",
      }
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  
  throw new Error("Failed to generate image");
}
